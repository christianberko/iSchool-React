Christian Berko

Components Used

MUI: Modal
Semanitic: Modal (couldn't get it to work)
Ant-Design: Accordian, Table, Menu, Pagination

What was spectatular:

I tried to make the website look kinda 3-d and so everything is somewhat elevated even the people cards have a small animation to them onclick and hover. But obviously unfinished as I couldn't get the nested Modal situation to work with the Minors :(.......